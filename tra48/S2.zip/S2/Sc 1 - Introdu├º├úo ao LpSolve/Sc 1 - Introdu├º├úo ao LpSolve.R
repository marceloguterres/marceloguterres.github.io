install.packages("lpSolve")
library(lpSolve)

# Definir a função objetivo (maximizar o retorno)
f.obj = c(6, 4)

# Definir a matriz de coeficientes das restrições
f.con = matrix(c(
  50, 30,  # Restrição de orçamento total
  50,  0,  # Restrição de investimento máximo em TeleMundo
  0, 30   # Restrição de investimento máximo em CosmoFone
), nrow=3, byrow=TRUE)

# Definir as direções das desigualdades
f.dir = c("<=", "<=", "<=")

# Definir os lados direitos das restrições
f.rhs = c(90000, 60000, 60000)

# Resolver o problema de programação linear
resultado <- lp("max", f.obj, f.con, f.dir, f.rhs)

# Exibir a solução
print("Solução ótima:")
print(paste("Ações da TeleMundo:", round(resultado$solution[1])))
print(paste("Ações da CosmoFone:", round(resultado$solution[2])))
print(paste("Retorno máximo: R$", round(resultado$objval, 2)))
